const scoreElement = document.getElementById("score");
let score = 0;

document.addEventListener("DOMContentLoaded", () => {
  setInterval(generateRandomPosition, 2000);

  document.addEventListener("click", addPoint);
});

function generateRandomPosition() {
  const windowWidth = window.innerWidth;
  const windowHeight = window.innerHeight;

  const randomX = Math.floor(Math.random() * windowWidth);
  const randomY = Math.floor(Math.random() * windowHeight);

  const dot = document.createElement("div");
  dot.classList.add("dot");
  dot.style.left = `${randomX}px`;
  dot.style.top = `${randomY}px`;
  document.body.appendChild(dot);

  setTimeout(() => {
    dot.remove();
  }, 2000);
}

function addPoint(event) {
  const elementClicked = event.target;
  if (elementClicked.classList.contains("dot")) {
    elementClicked.remove();
    score++;
    scoreElement.textContent = `Hisob: ${score}`;
  }
}
